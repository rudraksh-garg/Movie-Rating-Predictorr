# Suggested Mid-term / Final SML Presentation (12 slides)

1. **Title** — Movie Rating Prediction Using Machine Learning; course, student and guide details.
2. **Problem identification** — problem statement, motivation, objectives and intended output.
3. **Dataset and source feasibility** — MovieLens latest-small, three CSV files, source and feasibility; IMDb ID is a link, not the training rating source.
4. **Dataset collection** — rows/columns of ratings, movies and links; show a small real sample from your local data.
5. **Preprocessing** — cleaning, merge by movieId, year extraction, genre indicators; before/after example.
6. **EDA** — rating distribution, genre average and most-rated movies using generated charts.
7. **System architecture** — Movie search → MovieLens data → preprocessing/features → regression model → predicted user rating → recommendations.
8. **Algorithms** — global mean baseline, Ridge Regression and Random Forest; concise explanation of each.
9. **Evaluation** — MAE, RMSE and R² table copied from `outputs/model_metrics.csv`; actual-vs-predicted graph.
10. **Working prototype** — screenshot of CineRate app; search using a movie title or IMDb ID; show user-specific prediction and IMDb link.
11. **Progress report and limitations** — implementation evidence, actual completion state, random split limitations, no live IMDb score claim.
12. **Conclusion and future scope** — what works, what was learned, future matrix factorisation/cold-start/temporal evaluation; references.

## Evidence checklist before presenting
- Run `main.py` successfully and keep the terminal's metric output.
- Confirm that `outputs/model_metrics.csv` contains actual metrics.
- Open `outputs/` and use the actual generated plots.
- Run the Streamlit app and take a screenshot of the search and prediction result.
- Show that the app works without an API key.
- Explain clearly that the MovieLens community average is not an IMDb rating.
- Add your correct name, roll number, section and faculty guide.
