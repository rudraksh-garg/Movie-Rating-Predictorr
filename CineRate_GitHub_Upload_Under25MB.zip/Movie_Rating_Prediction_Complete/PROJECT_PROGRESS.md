# Project Progress / Completion Evidence Checklist

Use this checklist after completing the setup and running the application on your own computer. Do not mark a task complete until you have the corresponding local evidence.

| Rubric workstream | Implemented in project | Evidence to show your teacher |
|---|---|---|
| Problem identification and objectives | Yes | Project report sections 1–2 and About Project page |
| Dataset/source identification and feasibility | Yes | Official GroupLens source, dataset README, source/feasibility section |
| Dataset collection | Yes | `download_dataset.py`, local `ratings.csv`, `movies.csv`, `links.csv` |
| Preprocessing | Yes | `src/data_utils.py`; show merged table and feature columns |
| Exploratory data analysis | Yes | `outputs/rating_distribution.png`, `average_rating_by_genre.png`, `most_rated_movies.png` |
| ML implementation | Yes | `src/modeling.py`; baseline, Ridge Regression and Random Forest |
| Model evaluation | Yes | `outputs/model_metrics.csv`, `actual_vs_predicted.png`, `model_comparison.png` |
| Working application | Yes | Streamlit app search, prediction, recommendations and insights pages |
| Limitations and future scope | Yes | Project report and About Project page |
| Presentation/viva material | Yes | `PRESENTATION_OUTLINE.md` and `VIVA_NOTES.md` |

## Final local verification

- [ ] `setup_windows.bat` completes without errors.
- [ ] `python main.py` trains and evaluates all models.
- [ ] `outputs/model_metrics.csv` contains real local run results.
- [ ] The Streamlit app opens using `run_app.bat`.
- [ ] A known MovieLens title can be searched successfully.
- [ ] A linked IMDb ID can open the matching IMDb title page.
- [ ] A user-specific estimate and community average are clearly labelled separately.
- [ ] Recommendations appear for a selected MovieLens user.
- [ ] Screenshots are added to the final presentation.

The software implementation is provided; the checklist evidence must be generated on the student's computer after setup. A grade cannot be guaranteed because the evaluator's rubric and demonstration are outside the project files.
