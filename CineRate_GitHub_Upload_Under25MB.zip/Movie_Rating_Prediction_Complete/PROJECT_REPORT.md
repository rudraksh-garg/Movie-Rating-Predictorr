# Movie Rating Prediction Using Machine Learning

## Abstract
This project develops a movie-rating prediction prototype using the MovieLens latest-small dataset. It combines anonymised user ratings with movie metadata and trains regression models to estimate how a selected user may rate a movie. A Streamlit interface allows catalogue search by movie title, MovieLens ID or a linked IMDb ID, displays rating summaries, predicts a user-specific rating and generates recommendations. Model performance is assessed using MAE, RMSE and R² on a held-out test set.

## 1. Problem identification
Movie ratings are subjective and vary across users. A movie's genre, release year and the rating patterns of users and movies can provide signals about a likely rating. The project formulates this as a regression task: estimate a numerical rating on the MovieLens 0.5-to-5.0 scale for a user–movie pair.

## 2. Objectives
- Obtain a real publicly documented user–movie ratings dataset.
- Integrate ratings with movie titles, release years, genres and IMDb identifiers.
- Perform data cleaning and exploratory data analysis.
- Train and compare a baseline, Ridge Regression and Random Forest Regression.
- Evaluate the models with MAE, RMSE and R².
- Build a user-friendly interactive interface for searching and predicting.

## 3. Dataset and data source
The project uses MovieLens latest-small distributed by GroupLens Research. Its README reports 100,836 ratings from 610 users on 9,742 movies, with 3,683 tag applications. The three files used are `ratings.csv`, `movies.csv` and `links.csv`.

- `ratings.csv`: userId, movieId, rating and timestamp.
- `movies.csv`: movieId, title and pipe-separated genres.
- `links.csv`: MovieLens movieId mapped to IMDb and TMDb identifiers where available.

MovieLens is used for training and evaluation. The IMDb ID is used to construct a link to the corresponding IMDb title page; it is not used to retrieve or represent a live IMDb rating.

## 4. Feasibility
**Technical:** Python, pandas, scikit-learn and Streamlit are sufficient to load, preprocess, train, evaluate and present the prototype.  
**Operational:** The catalogue and rating data are stored locally after the first dataset download, so the core application works offline.  
**Economic:** The selected software stack is open-source and the education/development dataset is available from GroupLens subject to its stated terms.  
**Limitations:** The catalogue is not the entire IMDb database, and MovieLens user IDs are anonymised research IDs.

## 5. Dataset collection and preprocessing
The dataset downloader retrieves the official small archive on first run. The project then:
1. Loads ratings, movies and link tables with pandas.
2. Removes rows with missing user, movie or rating identifiers/values.
3. Checks that ratings lie within the 0.5–5.0 range.
4. Removes duplicate movie records.
5. Merges ratings and movie metadata through `movieId`.
6. Extracts the release year from the year in parentheses in the movie title; unavailable years are filled using the median year.
7. Converts each genre into a binary indicator feature.
8. Preserves IMDb IDs as external title-page links rather than model targets.

## 6. Exploratory data analysis
The application and training script generate:
- Rating distribution: frequency of each half-star rating.
- Average rating by genre: descriptive mean rating across genres.
- Most-rated movies: titles with the largest number of ratings.
- A sample of merged user–movie records.

These plots are descriptive. A higher average rating in a genre does not prove that genre causes a higher rating; popularity and user selection may affect the result.

## 7. Methodology and model development
The merged rating table is split into 80% training and 20% testing using a fixed random seed of 42.

### Global Mean Baseline
Predicts the average rating in the training set for every test example. It provides a simple reference to check whether more advanced models learn useful patterns.

### Ridge Regression
A regularised linear regression model. User IDs and movie IDs are one-hot encoded, and release year plus genre indicators are numerical inputs. L2 regularisation reduces instability from many sparse categorical features.

### Random Forest Regressor
An ensemble of decision trees. Its inputs include release year, genre indicators, historical user mean/count and historical movie mean/count. To prevent a training example's own rating from entering its history averages, training history features use leave-one-out calculations. Test history features use statistics from training data only.

## 8. Evaluation
The script calculates:

- **MAE:** mean absolute difference between actual and predicted ratings. Lower is better.
- **RMSE:** square root of mean squared error. It penalises larger errors more strongly. Lower is better.
- **R²:** proportion of target variance explained relative to a constant-mean reference. Higher is generally better; it may be negative.

The actual metric values are generated locally by running `python main.py` and saved to `outputs/model_metrics.csv`. Do not copy example or fabricated numbers into the report; use the values printed by the run.

## 9. Application workflow
1. User enters a title, MovieLens ID or linked IMDb ID.
2. The local MovieLens catalogue is searched.
3. User selects an anonymised MovieLens user profile.
4. The trained model estimates the selected user's rating for the movie.
5. The app displays the estimate alongside the MovieLens community mean and count.
6. The app can recommend movies the selected user has not rated, ranked by predicted rating.
7. An IMDb title-page link is offered where an IMDb mapping exists.

## 10. Results and limitations
The system provides a complete working educational pipeline from dataset acquisition to an interactive prediction screen. Performance must be interpreted in light of the random rating-level split: the same users and movies may occur in both train and test data. Therefore, the reported metrics do not represent performance on completely new users or completely new movies. The model estimates are not live IMDb ratings and are not guaranteed preferences.

## 11. Future scope
- Evaluate with temporal and user-wise splits.
- Add matrix factorisation and compare it against the current regressors.
- Tune hyperparameters using cross-validation.
- Add cold-start handling for unseen users and movies.
- Integrate additional movie metadata or posters using a permitted external API, with credentials kept securely outside source code.

## References
1. Harper, F. M., & Konstan, J. A. (2015). The MovieLens Datasets: History and Context. *ACM Transactions on Interactive Intelligent Systems*, 5(4). https://doi.org/10.1145/2827872
2. GroupLens Research. MovieLens Latest Datasets. https://grouplens.org/datasets/movielens/latest/
3. Scikit-learn documentation. https://scikit-learn.org/stable/
4. Streamlit documentation. https://docs.streamlit.io/
5. pandas documentation. https://pandas.pydata.org/docs/
