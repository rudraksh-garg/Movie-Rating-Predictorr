# Viva Preparation — Movie Rating Prediction

## 30-second project explanation
“Our project predicts the rating a selected MovieLens user may give to a movie. We use the real MovieLens latest-small dataset, which contains user ratings, movie titles, genres and IMDb ID mappings. We preprocess and explore the data, train a baseline, Ridge Regression and Random Forest Regressor, compare them with MAE, RMSE and R², and demonstrate predictions through a Streamlit application. IMDb IDs are used to link to title pages; the model is trained on MovieLens ratings, not live IMDb scores.”

## Common questions and answers

**1. What is the problem statement?**  
To estimate the numerical rating a user may give to a movie based on historical rating patterns and movie information.

**2. Why is this regression?**  
The target is a continuous numerical score on a 0.5–5.0 scale, not a class label.

**3. Which dataset is used?**  
MovieLens latest-small from GroupLens. Its README reports 100,836 ratings, 9,742 movies and 610 users.

**4. What are the main files?**  
`ratings.csv` stores userId, movieId, rating and timestamp; `movies.csv` stores movieId, title and genres; `links.csv` maps MovieLens movie IDs to IMDb/TMDb IDs when available.

**5. How are tables merged?**  
The ratings table is joined with movies and links using the common `movieId` column.

**6. What is preprocessing?**  
Cleaning missing or invalid rating records, removing duplicate movie rows, extracting the year from the title, filling unavailable years, and converting genres to binary indicator columns.

**7. What is EDA?**  
Exploratory Data Analysis. We inspect rating frequencies, average rating by genre and the most-rated movies to understand the dataset.

**8. Why use a train-test split?**  
The training set is used to learn model parameters; the separate test set estimates performance on examples not used during fitting. We use an 80:20 split and fixed random seed 42.

**9. What is the baseline model?**  
It predicts the mean of the training ratings for every test row. Advanced models should perform better than this simple reference.

**10. What is Ridge Regression?**  
Ridge is linear regression with an L2 penalty. It helps control large coefficients when there are many encoded user and movie features.

**11. What is Random Forest?**  
It is an ensemble of decision trees. Each tree learns patterns, and their predictions are combined, helping capture non-linear relationships.

**12. Why encode genres?**  
Algorithms require numerical input. Binary indicators represent whether a movie belongs to each genre.

**13. What is One-Hot Encoding?**  
It converts a categorical value into binary columns. For example, different user or movie IDs become separate indicator features.

**14. What is MAE?**  
Mean Absolute Error: average absolute difference between actual and predicted values. Smaller MAE means predictions are closer on average.

**15. What is RMSE?**  
Root Mean Squared Error: square root of average squared error. Large mistakes affect RMSE more strongly. Smaller is better.

**16. What is R²?**  
A metric comparing model error with a mean-prediction reference. Values closer to 1 are generally better; a negative score means the model performs worse than predicting the test mean.

**17. What does the application do?**  
It searches the local MovieLens catalogue by title, MovieLens ID or linked IMDb ID, selects an anonymised user profile, predicts the user's rating, compares estimates and recommends unrated movies.

**18. Does it fetch a live IMDb rating?**  
No. The current project does not scrape IMDb or use an IMDb API. It uses MovieLens ratings for machine learning and uses the IMDb identifier only to open the corresponding IMDb title page when available.

**19. What does the MovieLens community average mean?**  
It is the arithmetic mean of the ratings in this MovieLens dataset for that movie. It is not the IMDb score.

**20. What is the limitation of the evaluation?**  
The split is at rating-row level, so some users and movies occur in both training and testing. It does not test cold-start performance for unseen users/movies.

**21. What is the future scope?**  
Try matrix factorisation, hyperparameter tuning, temporal or user-wise evaluation, cold-start strategies and approved poster/metadata APIs.

## Metrics to fill in after running main.py

| Model | MAE | RMSE | R² |
|---|---:|---:|---:|
| Global Mean Baseline | Copy from outputs/model_metrics.csv | | |
| Ridge Regression | Copy from outputs/model_metrics.csv | | |
| Random Forest Regressor | Copy from outputs/model_metrics.csv | | |

Never invent these values. Run `python main.py` and use the metrics generated on your computer.
