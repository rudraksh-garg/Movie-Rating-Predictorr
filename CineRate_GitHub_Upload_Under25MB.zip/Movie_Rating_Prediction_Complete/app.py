from __future__ import annotations

import html
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

from src.data_utils import DatasetSetupError, load_dataset, resolve_movie_query, PROJECT_ROOT
from src.modeling import BUNDLE_PATH, predict_user_movie, recommend_movies, train_and_save

st.set_page_config(
    page_title="CineRate | Movie Rating Intelligence",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded",
)

CUSTOM_CSS = """
<style>
:root { --ink: #f4f2ff; --muted: #a8a4bf; --panel: #151525; --line: rgba(255,255,255,.10); }
.stApp { background: radial-gradient(circle at 12% 0%, rgba(108,99,255,.18), transparent 30%), linear-gradient(140deg,#0b0b14 0%,#10101d 55%,#151222 100%); color: var(--ink); }
.block-container { max-width: 1220px; padding-top: 2rem; padding-bottom: 3rem; }
[data-testid="stSidebar"] { background: #10101b; border-right: 1px solid var(--line); }
.hero { padding: 1.45rem 1.6rem; border: 1px solid rgba(255,255,255,.12); border-radius: 22px; background: linear-gradient(115deg,rgba(108,99,255,.25),rgba(22,166,161,.12)),rgba(20,20,36,.82); margin-bottom: 1.2rem; }
.hero-kicker { color:#b8b4ff; font-size:.78rem; font-weight:700; letter-spacing:.15em; text-transform:uppercase; }
.hero h1 { color:#fff; font-size:2.2rem; margin:.35rem 0 .35rem 0; letter-spacing:-.04em; }
.hero p { color:#c5c1d8; margin:0; font-size:1rem; }
.metric-card { background:rgba(255,255,255,.045); border:1px solid var(--line); padding:1rem 1.1rem; border-radius:16px; min-height:108px; }
.metric-label { color:#aaa6c1; font-size:.78rem; text-transform:uppercase; letter-spacing:.08em; }
.metric-value { color:#fff; font-size:1.75rem; font-weight:750; margin-top:.25rem; }
.metric-note { color:#aaa6c1; font-size:.78rem; margin-top:.15rem; }
.movie-card { background:linear-gradient(145deg,rgba(108,99,255,.11),rgba(255,255,255,.035)); border:1px solid var(--line); border-radius:17px; padding:1rem; min-height:150px; }
.movie-title { color:white; font-weight:700; font-size:1rem; line-height:1.3; }
.movie-meta { color:#aaa6c1; font-size:.82rem; margin-top:.45rem; }
.movie-score { color:#8de1d8; font-weight:750; font-size:1.35rem; margin-top:.6rem; }
.section-title { color:#fff; font-size:1.23rem; font-weight:750; margin:.3rem 0 .75rem 0; }
.small-muted { color:#a8a4bf; font-size:.84rem; }
div[data-testid="stMetric"] { background:rgba(255,255,255,.045); padding:12px 14px; border:1px solid var(--line); border-radius:14px; }
.stButton>button[kind="primary"] { border:0; border-radius:12px; font-weight:700; background:linear-gradient(90deg,#7168ff,#18a89f); }
.stTextInput input, .stNumberInput input, .stSelectbox div[data-baseweb="select"] { border-radius:10px; }
hr { border-color:var(--line); }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def metric_card(label: str, value: str, note: str = ""):
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{html.escape(label)}</div>'
        f'<div class="metric-value">{html.escape(value)}</div>'
        f'<div class="metric-note">{html.escape(note)}</div></div>',
        unsafe_allow_html=True,
    )


def movie_card(row, score_label="Community rating"):
    title = html.escape(str(row.get("title", "Unknown movie")))
    genres = html.escape(str(row.get("genres", "Genre unavailable")).replace("|", " · "))
    year = int(row.get("year", 0) or 0)
    score = float(row.get("movie_mean", 0) or 0)
    count = int(row.get("movie_count", 0) or 0)
    st.markdown(
        f'<div class="movie-card"><div style="font-size:1.5rem">🎞️</div>'
        f'<div class="movie-title">{title}</div><div class="movie-meta">{year if year else "Year unknown"} · {genres}</div>'
        f'<div class="movie-score">★ {score:.2f}/5</div>'
        f'<div class="small-muted">{count:,} MovieLens ratings · {html.escape(score_label)}</div></div>',
        unsafe_allow_html=True,
    )


@st.cache_data(show_spinner="Loading MovieLens data...")
def get_data():
    return load_dataset(download=True)


@st.cache_resource(show_spinner="Training machine-learning models for first use...")
def get_bundle():
    return train_and_save(force=False)


try:
    ratings, movies, links, merged, genre_names, genre_cols = get_data()
except DatasetSetupError as exc:
    st.markdown('<div class="hero"><div class="hero-kicker">Statistical Machine Learning Project</div><h1>🎬 CineRate</h1><p>Movie Rating Prediction & Personalised Movie Insights</p></div>', unsafe_allow_html=True)
    st.error("The MovieLens dataset is not available yet.")
    st.code("python download_dataset.py\npython main.py\npython -m streamlit run app.py", language="powershell")
    st.markdown(str(exc))
    st.stop()

try:
    bundle = get_bundle()
except Exception as exc:
    st.error(f"Model training/loading failed: {exc}")
    st.info("Run `python main.py` in the project folder to train and save the model, then refresh this page.")
    st.stop()

st.markdown(
    '<div class="hero"><div class="hero-kicker">Statistical Machine Learning · Recommendation Analytics</div>'
    '<h1>🎬 CineRate</h1><p>Explore movies, predict personalised ratings, and discover your next watch.</p></div>',
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown("## 🎬 CineRate")
    st.caption("Movie Rating Prediction System")
    page = st.radio("Navigate", ["Movie Predictor", "For You", "Data & Insights", "Model Evaluation", "About Project"], label_visibility="collapsed")
    st.divider()
    st.markdown("**Personal profile**")
    user_ids = bundle["user_ids"]
    selected_user = st.selectbox("MovieLens User ID", user_ids, index=0, help="MovieLens IDs are anonymised sample users, not personal accounts.")
    st.caption("Select a sample user profile to make personalised predictions.")
    st.divider()
    st.caption("Dataset: MovieLens latest-small")
    st.caption("No OMDb API key required. Searches use the local catalogue.")

if page == "Movie Predictor":
    st.markdown('<div class="section-title">Find a movie and predict its rating</div>', unsafe_allow_html=True)
    st.markdown('<div class="small-muted">Search by movie title, MovieLens movie ID, or IMDb ID (for example, tt0111161). The movie must be present in the MovieLens catalogue.</div>', unsafe_allow_html=True)
    with st.form("movie_search_form"):
        query = st.text_input("Movie search", placeholder="Try: The Shawshank Redemption or tt0111161")
        model_options = ["Best model (auto-selected)", "Ridge Regression", "Random Forest Regressor"]
        chosen_model = st.selectbox("Prediction model", model_options)
        submitted = st.form_submit_button("Search movie & predict", type="primary", use_container_width=True)

    if submitted:
        found = resolve_movie_query(query, movies, links, limit=25)
        if found.empty:
            st.warning("No matching movie was found in the MovieLens catalogue. Check the spelling or try another title/IMDb ID.")
        else:
            st.session_state["search_results"] = found
            st.session_state["query_model"] = chosen_model

    found = st.session_state.get("search_results")
    if found is not None and not found.empty:
        if len(found) > 1:
            options = {f"{r.title}  ·  {int(r.year) if int(r.year) else 'Year unknown'}  ·  {int(r.movie_count):,} ratings": int(r.movieId) for r in found.itertuples()}
            chosen_label = st.selectbox("Choose the correct match", list(options.keys()))
            chosen_movie_id = options[chosen_label]
            selected_movie = movies[movies["movieId"] == chosen_movie_id].iloc[0]
        else:
            selected_movie = found.iloc[0]

        requested_model = st.session_state.get("query_model", "Best model (auto-selected)")
        actual_model = bundle["best_model_name"] if requested_model == "Best model (auto-selected)" else requested_model
        result = predict_user_movie(bundle, int(selected_user), selected_movie, model_name=actual_model)
        st.divider()
        left, right = st.columns([1.35, 1])
        with left:
            st.markdown(f"### {selected_movie['title']}")
            st.caption(f"{int(selected_movie['year']) if int(selected_movie['year']) else 'Release year unavailable'} · {str(selected_movie['genres']).replace('|', ' · ')}")
            st.write("This prediction estimates how the selected MovieLens user may rate this movie, based on rating history and movie information.")
            imdb = selected_movie.get("imdbId")
            if pd.notna(imdb) and str(imdb).strip() not in {"", "0", "nan"}:
                imdb_url = f"https://www.imdb.com/title/tt{int(imdb):07d}/"
                st.link_button("Open this title on IMDb ↗", imdb_url)
            else:
                st.caption("No IMDb link is available for this catalogue entry.")
        with right:
            st.markdown("#### Prediction result")
            st.metric("Estimated user rating", f"{result['predicted_rating']:.2f} / 5")
            st.caption(f"Model: {result['selected_model']} · User profile: {selected_user}")
            st.metric("MovieLens community average", f"{float(selected_movie['movie_mean']):.2f} / 5", f"{int(selected_movie['movie_count']):,} ratings")
        st.markdown("#### Compare model estimates")
        c1, c2, c3 = st.columns(3)
        c1.metric("Ridge Regression", f"{result['predictions']['Ridge Regression']:.2f}/5")
        c2.metric("Random Forest", f"{result['predictions']['Random Forest Regressor']:.2f}/5")
        c3.metric("Global baseline", f"{result['predictions']['Global Mean Baseline']:.2f}/5")
        st.info("The community average is calculated from MovieLens user ratings. It is not a live IMDb score. The model estimate is a separate machine-learning prediction.")

elif page == "For You":
    st.markdown('<div class="section-title">Recommended for your selected profile</div>', unsafe_allow_html=True)
    st.caption(f"Recommendations are generated for anonymised MovieLens user {selected_user}, excluding movies already rated by that user.")
    with st.spinner("Finding movies you may enjoy..."):
        recs = recommend_movies(bundle, int(selected_user), movies, ratings, limit=8)
    if recs.empty:
        st.info("No recommendations are available for this user profile.")
    else:
        cols = st.columns(4)
        for i, (_, row) in enumerate(recs.iterrows()):
            with cols[i % 4]:
                movie_card(row, "Community average")
                st.metric("Predicted for this user", f"{row['predicted_rating']:.2f}/5")
                imdb = row.get("imdbId")
                if pd.notna(imdb) and str(imdb).strip() not in {"", "0", "nan"}:
                    st.link_button("IMDb ↗", f"https://www.imdb.com/title/tt{int(imdb):07d}/", use_container_width=True)

elif page == "Data & Insights":
    st.markdown('<div class="section-title">Dataset overview & exploratory analysis</div>', unsafe_allow_html=True)
    k1, k2, k3, k4 = st.columns(4)
    with k1: metric_card("Ratings", f"{len(ratings):,}", "Individual user-movie ratings")
    with k2: metric_card("Movies", f"{movies['movieId'].nunique():,}", "Movie catalogue records")
    with k3: metric_card("Users", f"{ratings['userId'].nunique():,}", "Anonymised user profiles")
    with k4: metric_card("Genres", f"{len(genre_names)}", "Movie genre categories")
    st.markdown("#### Rating distribution")
    counts = ratings["rating"].value_counts().sort_index()
    st.bar_chart(counts)
    left, right = st.columns(2)
    with left:
        st.markdown("#### Average rating by genre")
        genre_summary = merged.assign(genre=merged["genres"].str.split("|")).explode("genre")
        genre_summary = genre_summary[genre_summary["genre"] != "(no genres listed)"]
        genre_avg = genre_summary.groupby("genre")["rating"].mean().sort_values()
        st.bar_chart(genre_avg)
    with right:
        st.markdown("#### Most rated movies")
        top_movies = movies.nlargest(10, "movie_count").set_index("title")["movie_count"].sort_values()
        st.bar_chart(top_movies)
    st.markdown("#### Dataset sample")
    st.dataframe(merged[["userId", "movieId", "title", "genres", "year", "rating"]].head(12), use_container_width=True, hide_index=True)
    st.caption("Dataset: MovieLens latest-small from GroupLens. Ratings are on a 0.5–5.0 star scale.")

elif page == "Model Evaluation":
    st.markdown('<div class="section-title">Model training & evaluation</div>', unsafe_allow_html=True)
    st.caption("Models are evaluated on a held-out 20% test split using a fixed random seed (42). Lower MAE/RMSE is better; higher R² is generally better.")
    metrics = pd.DataFrame(bundle["metrics"]).sort_values("RMSE")
    st.success(f"Best model by RMSE: {bundle['best_model_name']}")
    st.dataframe(metrics.style.format({"MAE": "{:.4f}", "RMSE": "{:.4f}", "R2": "{:.4f}"}), use_container_width=True, hide_index=True)
    left, right = st.columns(2)
    with left:
        chart_path = PROJECT_ROOT / "outputs" / "model_comparison.png"
        if chart_path.exists():
            st.image(str(chart_path), caption="MAE and RMSE comparison")
    with right:
        chart_path = PROJECT_ROOT / "outputs" / "actual_vs_predicted.png"
        if chart_path.exists():
            st.image(str(chart_path), caption="Held-out actual versus predicted ratings")
    st.markdown("#### What the algorithms do")
    st.markdown("- **Global Mean Baseline:** predicts the mean rating from training data; this is a simple reference point.\n- **Ridge Regression:** linear regression with L2 regularisation; user and movie IDs are one-hot encoded, while year and genre indicators are numerical features.\n- **Random Forest Regressor:** combines decision trees and uses user/movie history summaries, release year, and genre indicators.")
    st.warning("Evaluation uses a random rating-level split. This measures prediction on held-out ratings for users and movies that may also appear in training. It is not a strict cold-start evaluation for completely new users or movies.")

elif page == "About Project":
    st.markdown('<div class="section-title">Project methodology</div>', unsafe_allow_html=True)
    steps = [
        ("01", "Dataset collection", "Load ratings.csv, movies.csv and links.csv from the official MovieLens latest-small dataset."),
        ("02", "Preprocessing", "Validate rating values, remove incomplete rating rows, merge tables using movieId, extract release year and encode genres."),
        ("03", "Exploratory analysis", "Study the rating distribution, average rating by genre and most-rated movies."),
        ("04", "Model development", "Train a baseline, Ridge Regression and Random Forest Regressor."),
        ("05", "Evaluation", "Compare models using MAE, RMSE and R² on a held-out test set."),
        ("06", "Application", "Search by title or linked IMDb ID, select a MovieLens user profile, predict ratings and display recommendations."),
    ]
    for num, title, desc in steps:
        st.markdown(f"**{num} · {title}**  \n{desc}")
        st.divider()
    st.markdown("#### Important project scope")
    st.write("The app does not scrape IMDb and does not claim to show a live IMDb rating. It uses MovieLens ratings to train and evaluate the ML models, and the IMDb ID is used only to link the corresponding title to its IMDb page when a mapping exists.")
    st.markdown("#### Dataset citation")
    st.write("Harper, F. M., & Konstan, J. A. (2015). The MovieLens Datasets: History and Context. ACM Transactions on Interactive Intelligent Systems, 5(4). https://doi.org/10.1145/2827872")

st.divider()
st.caption("CineRate · Movie Rating Prediction using Statistical Machine Learning · Academic prototype")
