from src.data_utils import ensure_dataset

if __name__ == "__main__":
    folder = ensure_dataset()
    print(f"MovieLens dataset is ready: {folder}")
    print("Dataset files:")
    for name in ("ratings.csv", "movies.csv", "links.csv", "tags.csv"):
        path = folder / name
        if path.exists():
            print(f"  {name}: {path.stat().st_size:,} bytes")
