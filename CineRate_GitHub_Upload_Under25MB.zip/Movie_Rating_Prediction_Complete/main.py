"""Train and evaluate the Movie Rating Prediction models, then save charts and metrics."""
from src.modeling import train_and_save

if __name__ == "__main__":
    print("=" * 68)
    print("MOVIE RATING PREDICTION - TRAINING AND EVALUATION")
    print("=" * 68)
    print("1) Checking the real MovieLens dataset...")
    print("2) Training baseline, Ridge Regression and Random Forest models...")
    print("3) Evaluating on a held-out 20% test split...")
    bundle = train_and_save(force=True)
    print("\nMODEL RESULTS")
    for row in sorted(bundle["metrics"], key=lambda item: item["RMSE"]):
        print(f"{row['Model']:<27} MAE={row['MAE']:.4f}  RMSE={row['RMSE']:.4f}  R2={row['R2']:.4f}")
    print(f"\nBest model by RMSE: {bundle['best_model_name']}")
    print(f"Ratings: {bundle['dataset_rows']:,} | Movies: {bundle['movie_count']:,} | Users: {bundle['user_count']:,}")
    print("\nSaved model: models/movie_rating_models.joblib")
    print("Saved charts and metrics: outputs/")
    print("Training completed successfully.")
