@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\activate.bat" (
    call .venv\Scripts\activate.bat
)
python -m streamlit run app.py
if errorlevel 1 (
    echo.
    echo Could not start CineRate. Run setup_windows.bat first.
    pause
)
