@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo CineRate - One-time Windows setup
echo ============================================================
where py >nul 2>nul
if %errorlevel%==0 (
    py -m venv .venv
) else (
    python -m venv .venv
)
if not exist ".venv\Scripts\activate.bat" (
    echo Could not create the virtual environment. Check your Python installation.
    pause
    exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto failed
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
python download_dataset.py
if errorlevel 1 goto failed
python main.py
if errorlevel 1 goto failed
echo.
echo SETUP COMPLETE. Double-click run_app.bat to open CineRate.
pause
exit /b 0
:failed
echo.
echo Setup failed. Read the error above and see README.md - Troubleshooting.
pause
exit /b 1
