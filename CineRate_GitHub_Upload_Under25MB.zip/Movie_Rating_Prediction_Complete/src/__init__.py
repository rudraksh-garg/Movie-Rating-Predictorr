"""Movie Rating Prediction project package."""
