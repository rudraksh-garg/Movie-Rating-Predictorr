from __future__ import annotations

import re
import urllib.request
import zipfile
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
DATASET_DIR = DATA_DIR / "ml-latest-small"
DATASET_URL = "https://files.grouplens.org/datasets/movielens/ml-latest-small.zip"
REQUIRED_FILES = ("ratings.csv", "movies.csv", "links.csv")


class DatasetSetupError(RuntimeError):
    """Raised when the MovieLens dataset is unavailable or incomplete."""


def ensure_dataset() -> Path:
    """Ensure MovieLens latest-small is available locally; download it once if needed."""
    if all((DATASET_DIR / name).exists() for name in REQUIRED_FILES):
        return DATASET_DIR

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    archive = DATA_DIR / "ml-latest-small.zip"
    try:
        request = urllib.request.Request(
            DATASET_URL,
            headers={"User-Agent": "MovieRatingPredictionStudentProject/1.0"},
        )
        with urllib.request.urlopen(request, timeout=40) as response, archive.open("wb") as out:
            out.write(response.read())
        with zipfile.ZipFile(archive, "r") as zf:
            # Validate archive paths before extraction.
            root = DATA_DIR.resolve()
            for member in zf.infolist():
                target = (DATA_DIR / member.filename).resolve()
                if root not in target.parents and target != root:
                    raise DatasetSetupError("The downloaded dataset archive contains an unsafe path.")
            zf.extractall(DATA_DIR)
    except Exception as exc:
        raise DatasetSetupError(
            "The MovieLens dataset could not be downloaded automatically.\n\n"
            "Please download the official ml-latest-small.zip from "
            "https://grouplens.org/datasets/movielens/latest/ and extract the "
            "'ml-latest-small' folder into this project's 'data' folder.\n\n"
            f"Technical details: {exc}"
        ) from exc
    finally:
        if archive.exists():
            archive.unlink()

    if not all((DATASET_DIR / name).exists() for name in REQUIRED_FILES):
        raise DatasetSetupError(
            f"Dataset files are missing. Expected {', '.join(REQUIRED_FILES)} inside {DATASET_DIR}."
        )
    return DATASET_DIR


def extract_year(title: str) -> int:
    """Extract a four-digit release year from a MovieLens title."""
    match = re.search(r"\((\d{4})\)\s*$", str(title))
    return int(match.group(1)) if match else 0


def load_dataset(download: bool = True):
    """Load and merge ratings, movies and IMDb-link tables; return clean data objects."""
    if download:
        folder = ensure_dataset()
    else:
        folder = DATASET_DIR
        if not all((folder / name).exists() for name in REQUIRED_FILES):
            raise DatasetSetupError(f"Dataset files not found in {folder}")

    ratings = pd.read_csv(folder / "ratings.csv")
    movies = pd.read_csv(folder / "movies.csv")
    links = pd.read_csv(folder / "links.csv")

    required_rating_cols = {"userId", "movieId", "rating"}
    required_movie_cols = {"movieId", "title", "genres"}
    if not required_rating_cols.issubset(ratings.columns):
        raise DatasetSetupError(f"ratings.csv must contain {sorted(required_rating_cols)}")
    if not required_movie_cols.issubset(movies.columns):
        raise DatasetSetupError(f"movies.csv must contain {sorted(required_movie_cols)}")

    ratings = ratings.dropna(subset=["userId", "movieId", "rating"]).copy()
    ratings["userId"] = ratings["userId"].astype(int)
    ratings["movieId"] = ratings["movieId"].astype(int)
    ratings["rating"] = pd.to_numeric(ratings["rating"], errors="coerce")
    ratings = ratings.dropna(subset=["rating"])
    ratings = ratings[ratings["rating"].between(0.5, 5.0)].copy()

    movies = movies.drop_duplicates("movieId").copy()
    movies["movieId"] = movies["movieId"].astype(int)
    movies["genres"] = movies["genres"].fillna("(no genres listed)")
    movies["year"] = movies["title"].apply(extract_year).replace(0, pd.NA)
    median_year = int(movies["year"].dropna().median()) if movies["year"].notna().any() else 2000
    movies["year"] = movies["year"].fillna(median_year).astype(int)
    links = links.drop_duplicates("movieId").copy()
    if "imdbId" not in links.columns:
        links["imdbId"] = pd.NA

    merged = ratings.merge(movies[["movieId", "title", "genres", "year"]], on="movieId", how="inner")
    merged = merged.merge(links[["movieId", "imdbId"]], on="movieId", how="left")
    merged["year"] = merged["year"].astype(int)

    genre_names = sorted({
        genre
        for raw in movies["genres"].astype(str)
        for genre in raw.split("|")
        if genre and genre != "(no genres listed)"
    })
    genre_cols = [f"genre__{name}" for name in genre_names]
    for genre, col in zip(genre_names, genre_cols):
        merged[col] = merged["genres"].str.split("|").apply(lambda values: int(genre in values))
        movies[col] = movies["genres"].str.split("|").apply(lambda values: int(genre in values))

    movie_stats = ratings.groupby("movieId")["rating"].agg(movie_mean="mean", movie_count="count").reset_index()
    movies = movies.merge(movie_stats, on="movieId", how="left")
    movies["movie_mean"] = movies["movie_mean"].fillna(ratings["rating"].mean())
    movies["movie_count"] = movies["movie_count"].fillna(0).astype(int)
    movies = movies.merge(links[["movieId", "imdbId"]], on="movieId", how="left")
    return ratings, movies, links, merged, genre_names, genre_cols


def resolve_movie_query(query: str, movies: pd.DataFrame, links: pd.DataFrame, limit: int = 30) -> pd.DataFrame:
    """Search the local MovieLens catalogue by title, MovieLens ID, or IMDb ID."""
    query = str(query).strip()
    if not query:
        return movies.iloc[0:0].copy()
    if query.lower().startswith("tt") and query[2:].isdigit():
        imdb_number = int(query[2:])
        ids = links.loc[pd.to_numeric(links["imdbId"], errors="coerce") == imdb_number, "movieId"]
        return movies[movies["movieId"].isin(ids)].head(limit).copy()
    if query.isdigit():
        movie_id = int(query)
        exact_id = movies[movies["movieId"] == movie_id]
        if not exact_id.empty:
            return exact_id.head(limit).copy()
    mask = movies["title"].str.contains(query, case=False, regex=False, na=False)
    found = movies[mask].copy()
    if not found.empty:
        found = found.sort_values(["movie_count", "movie_mean"], ascending=[False, False])
    return found.head(limit)
