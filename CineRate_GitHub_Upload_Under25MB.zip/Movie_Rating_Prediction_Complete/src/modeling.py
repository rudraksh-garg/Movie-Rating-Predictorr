from __future__ import annotations

import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .data_utils import PROJECT_ROOT, load_dataset

MODEL_DIR = PROJECT_ROOT / "models"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
BUNDLE_PATH = MODEL_DIR / "movie_rating_models.joblib"


def metric_row(name, actual, predicted):
    predicted = np.clip(np.asarray(predicted, dtype=float), 0.5, 5.0)
    actual = np.asarray(actual, dtype=float)
    return {
        "Model": name,
        "MAE": float(mean_absolute_error(actual, predicted)),
        "RMSE": float(np.sqrt(mean_squared_error(actual, predicted))),
        "R2": float(r2_score(actual, predicted)),
    }


def _rf_features_fit(train: pd.DataFrame, genre_cols: list[str]):
    """Create leakage-safe leave-one-out history features for training rows."""
    global_mean = float(train["rating"].mean())
    user_stats = train.groupby("userId")["rating"].agg(["sum", "count"])
    movie_stats = train.groupby("movieId")["rating"].agg(["sum", "count"])
    u_sum = train["userId"].map(user_stats["sum"])
    u_count = train["userId"].map(user_stats["count"])
    m_sum = train["movieId"].map(movie_stats["sum"])
    m_count = train["movieId"].map(movie_stats["count"])

    features = pd.DataFrame(index=train.index)
    features["user_history_mean"] = ((u_sum - train["rating"]) / (u_count - 1)).where(u_count > 1, global_mean)
    features["user_history_count"] = (u_count - 1).clip(lower=0)
    features["movie_history_mean"] = ((m_sum - train["rating"]) / (m_count - 1)).where(m_count > 1, global_mean)
    features["movie_history_count"] = (m_count - 1).clip(lower=0)
    features["year"] = train["year"].astype(float)
    for col in genre_cols:
        features[col] = train[col].astype(float)
    stats = {
        "global_mean": global_mean,
        "user_mean": (user_stats["sum"] / user_stats["count"]).to_dict(),
        "user_count": user_stats["count"].to_dict(),
        "movie_mean": (movie_stats["sum"] / movie_stats["count"]).to_dict(),
        "movie_count": movie_stats["count"].to_dict(),
    }
    return features.fillna(global_mean), stats


def _rf_features_infer(rows: pd.DataFrame, stats: dict, genre_cols: list[str]) -> pd.DataFrame:
    global_mean = stats["global_mean"]
    features = pd.DataFrame(index=rows.index)
    features["user_history_mean"] = rows["userId"].map(stats["user_mean"]).fillna(global_mean).astype(float)
    features["user_history_count"] = rows["userId"].map(stats["user_count"]).fillna(0).astype(float)
    features["movie_history_mean"] = rows["movieId"].map(stats["movie_mean"]).fillna(global_mean).astype(float)
    features["movie_history_count"] = rows["movieId"].map(stats["movie_count"]).fillna(0).astype(float)
    features["year"] = rows["year"].astype(float)
    for col in genre_cols:
        features[col] = rows[col].astype(float) if col in rows else 0.0
    return features.fillna(global_mean)


def _plot_outputs(ratings, movies, merged, metrics, actual, predictions, best_model_name, genre_names):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")

    plt.figure(figsize=(8, 4.8))
    sns.countplot(data=ratings, x="rating", color="#6C63FF")
    plt.title("Distribution of User Ratings", fontsize=15, weight="bold")
    plt.xlabel("Rating (out of 5)")
    plt.ylabel("Number of ratings")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "rating_distribution.png", dpi=170)
    plt.close()

    genre_rows = merged[["rating", "genres"]].copy()
    genre_rows["genre"] = genre_rows["genres"].str.split("|")
    genre_rows = genre_rows.explode("genre")
    genre_rows = genre_rows[genre_rows["genre"] != "(no genres listed)"]
    avg_genre = genre_rows.groupby("genre")["rating"].mean().sort_values()
    plt.figure(figsize=(8, 6))
    avg_genre.plot(kind="barh", color="#16A6A1")
    plt.title("Average Rating by Genre", fontsize=15, weight="bold")
    plt.xlabel("Average rating (out of 5)")
    plt.ylabel("Genre")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "average_rating_by_genre.png", dpi=170)
    plt.close()

    popular = movies.sort_values("movie_count", ascending=False).head(12).sort_values("movie_count")
    plt.figure(figsize=(9, 6))
    plt.barh(popular["title"].str.slice(0, 38), popular["movie_count"], color="#F5A623")
    plt.title("Most Rated Movies in MovieLens", fontsize=15, weight="bold")
    plt.xlabel("Number of ratings")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "most_rated_movies.png", dpi=170)
    plt.close()

    metrics_df = pd.DataFrame(metrics).sort_values("RMSE")
    x = np.arange(len(metrics_df))
    width = 0.34
    plt.figure(figsize=(8, 4.8))
    plt.bar(x - width/2, metrics_df["MAE"], width, label="MAE", color="#6C63FF")
    plt.bar(x + width/2, metrics_df["RMSE"], width, label="RMSE", color="#16A6A1")
    plt.xticks(x, metrics_df["Model"], rotation=10)
    plt.ylabel("Error (lower is better)")
    plt.title("Model Comparison", fontsize=15, weight="bold")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "model_comparison.png", dpi=170)
    plt.close()

    pred = np.clip(np.asarray(predictions), 0.5, 5.0)
    plt.figure(figsize=(6.5, 5.5))
    plt.scatter(actual, pred, alpha=0.25, s=16, color="#6C63FF", edgecolors="none")
    plt.plot([0.5, 5], [0.5, 5], "--", color="#E45757", linewidth=2)
    plt.xlim(0.5, 5)
    plt.ylim(0.5, 5)
    plt.xlabel("Actual rating")
    plt.ylabel("Predicted rating")
    plt.title(f"Actual vs Predicted — {best_model_name}", fontsize=14, weight="bold")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "actual_vs_predicted.png", dpi=170)
    plt.close()

    pd.DataFrame(metrics).sort_values("RMSE").to_csv(OUTPUT_DIR / "model_metrics.csv", index=False)
    genre_rows.groupby("genre")["rating"].agg(["mean", "count"]).sort_values("mean", ascending=False).to_csv(OUTPUT_DIR / "genre_analysis.csv")


def train_and_save(force: bool = False) -> dict:
    """Train models on real MovieLens ratings, evaluate, save model bundle and charts."""
    if BUNDLE_PATH.exists() and not force:
        return joblib.load(BUNDLE_PATH)

    ratings, movies, links, merged, genre_names, genre_cols = load_dataset(download=True)
    train_idx, test_idx = train_test_split(merged.index, test_size=0.20, random_state=42)
    train = merged.loc[train_idx].copy()
    test = merged.loc[test_idx].copy()
    y_train = train["rating"].to_numpy()
    y_test = test["rating"].to_numpy()

    # Baseline: predict the global training-set mean for every test rating.
    train_global_mean = float(y_train.mean())
    baseline_pred = np.full(len(test), train_global_mean)
    metrics = [metric_row("Global Mean Baseline", y_test, baseline_pred)]

    # Regularized linear model: one-hot encode user and movie IDs, plus year and genre flags.
    numeric_cols = ["year"] + genre_cols
    preprocessor = ColumnTransformer(
        transformers=[
            ("ids", OneHotEncoder(handle_unknown="ignore"), ["userId", "movieId"]),
            ("numeric", StandardScaler(), numeric_cols),
        ],
        remainder="drop",
    )
    ridge = __import__("sklearn.pipeline", fromlist=["Pipeline"]).Pipeline([
        ("preprocess", preprocessor),
        ("model", Ridge(alpha=12.0, solver="lsqr")),
    ])
    ridge_columns = ["userId", "movieId"] + numeric_cols
    ridge.fit(train[ridge_columns], y_train)
    ridge_pred = np.clip(ridge.predict(test[ridge_columns]), 0.5, 5.0)
    metrics.append(metric_row("Ridge Regression", y_test, ridge_pred))

    # Random Forest uses leave-one-out training history features to avoid including
    # each training row's own target in its user/movie average feature.
    rf_train_x, train_stats = _rf_features_fit(train, genre_cols)
    rf_test_x = _rf_features_infer(test, train_stats, genre_cols)
    random_forest = RandomForestRegressor(
        n_estimators=100,
        max_depth=18,
        min_samples_leaf=3,
        max_features=0.85,
        random_state=42,
        n_jobs=-1,
    )
    random_forest.fit(rf_train_x, y_train)
    rf_pred = np.clip(random_forest.predict(rf_test_x), 0.5, 5.0)
    metrics.append(metric_row("Random Forest Regressor", y_test, rf_pred))

    metrics_df = pd.DataFrame(metrics).sort_values("RMSE")
    predictions_by_name = {
        "Global Mean Baseline": baseline_pred,
        "Ridge Regression": ridge_pred,
        "Random Forest Regressor": rf_pred,
    }
    best_name = str(metrics_df.iloc[0]["Model"])
    best_prediction = predictions_by_name[best_name]

    # Recalculate history statistics from all available ratings for serving predictions.
    full_user = ratings.groupby("userId")["rating"].agg(["sum", "count"])
    full_movie = ratings.groupby("movieId")["rating"].agg(["sum", "count"])
    full_stats = {
        "global_mean": float(ratings["rating"].mean()),
        "user_mean": (full_user["sum"] / full_user["count"]).to_dict(),
        "user_count": full_user["count"].to_dict(),
        "movie_mean": (full_movie["sum"] / full_movie["count"]).to_dict(),
        "movie_count": full_movie["count"].to_dict(),
    }

    bundle = {
        "ridge": ridge,
        "random_forest": random_forest,
        "metrics": metrics,
        "best_model_name": best_name,
        "genre_names": genre_names,
        "genre_cols": genre_cols,
        "stats": full_stats,
        "user_ids": sorted(int(x) for x in ratings["userId"].unique()),
        "movie_ids": sorted(int(x) for x in movies["movieId"].unique()),
        "dataset_rows": int(len(ratings)),
        "movie_count": int(movies["movieId"].nunique()),
        "user_count": int(ratings["userId"].nunique()),
        "train_rows": int(len(train)),
        "test_rows": int(len(test)),
        "random_state": 42,
    }
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, BUNDLE_PATH)
    _plot_outputs(ratings, movies, merged, metrics, y_test, best_prediction, best_name, genre_names)
    with (OUTPUT_DIR / "training_summary.json").open("w", encoding="utf-8") as f:
        json.dump({k: v for k, v in bundle.items() if k not in {"ridge", "random_forest", "stats"}}, f, indent=2)
    return bundle


def predict_user_movie(bundle: dict, user_id: int, movie_row: pd.Series | dict, model_name: str | None = None) -> dict:
    row = dict(movie_row)
    movie_id = int(row["movieId"])
    year = int(row.get("year", 2000) or 2000)
    row_data = {"userId": int(user_id), "movieId": movie_id, "year": year}
    for col in bundle["genre_cols"]:
        row_data[col] = int(row.get(col, 0))
    frame = pd.DataFrame([row_data])

    ridge_features = frame[["userId", "movieId", "year"] + bundle["genre_cols"]]
    ridge_pred = float(np.clip(bundle["ridge"].predict(ridge_features)[0], 0.5, 5.0))
    rf_features = _rf_features_infer(frame, bundle["stats"], bundle["genre_cols"])
    rf_pred = float(np.clip(bundle["random_forest"].predict(rf_features)[0], 0.5, 5.0))
    predictions = {
        "Ridge Regression": ridge_pred,
        "Random Forest Regressor": rf_pred,
        "Global Mean Baseline": float(bundle["stats"]["global_mean"]),
    }
    selected = model_name or bundle["best_model_name"]
    return {"selected_model": selected, "predicted_rating": predictions.get(selected, predictions[bundle["best_model_name"]]), "predictions": predictions}


def recommend_movies(bundle: dict, user_id: int, movies: pd.DataFrame, ratings: pd.DataFrame, limit: int = 8) -> pd.DataFrame:
    """Recommend highly predicted movies that this user has not rated yet."""
    already_seen = set(ratings.loc[ratings["userId"] == int(user_id), "movieId"].astype(int))
    candidates = movies[~movies["movieId"].isin(already_seen)].copy()
    candidates = candidates[candidates["movie_count"] >= 5]
    candidates = candidates.sort_values("movie_count", ascending=False).head(2500).copy()
    if candidates.empty:
        return candidates

    feature_rows = pd.DataFrame({
        "userId": int(user_id),
        "movieId": candidates["movieId"].astype(int).to_numpy(),
        "year": candidates["year"].astype(int).to_numpy(),
    })
    for col in bundle["genre_cols"]:
        feature_rows[col] = candidates[col].astype(int).to_numpy() if col in candidates else 0

    if bundle["best_model_name"] == "Ridge Regression":
        cols = ["userId", "movieId", "year"] + bundle["genre_cols"]
        preds = bundle["ridge"].predict(feature_rows[cols])
    elif bundle["best_model_name"] == "Random Forest Regressor":
        preds = bundle["random_forest"].predict(_rf_features_infer(feature_rows, bundle["stats"], bundle["genre_cols"]))
    else:
        preds = np.full(len(candidates), bundle["stats"]["global_mean"])
    candidates["predicted_rating"] = np.clip(preds, 0.5, 5.0)
    return candidates.sort_values(["predicted_rating", "movie_count"], ascending=[False, False]).head(limit)
